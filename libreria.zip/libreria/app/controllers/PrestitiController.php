<?php
namespace App\Controllers;
use App\Core\Auth;
use App\Core\Helpers;
use App\Models\Libro;
class PrestitiController {
  public function index() {
    Auth::require();
    $pdo = \App\Core\DB::conn();
    $sql = "SELECT o.id, o.titolo, o.prestito_data_inizio, o.prestito_data_fine, o.stato,
                   s.first_name, s.last_name
            FROM libri o
            LEFT JOIN students s ON s.id = o.prestito_student_id
            WHERE o.stato = 'In Prestito'
            ORDER BY o.prestito_data_inizio DESC";
    $rows = $pdo->query($sql)->fetchAll();
    Helpers::view('prestiti/index', ['title'=>'Prestiti','prestiti'=>$rows]);
  }
}
