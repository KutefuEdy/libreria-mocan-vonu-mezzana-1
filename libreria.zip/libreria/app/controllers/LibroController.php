<?php
namespace App\Controllers;

use App\Models\Libro;
use App\Core\Helpers;
use App\Core\Auth;

class LibroController {

    public function index() {
        Auth::require();
        $model = new Libro();
        $libri = $model->all();
        Helpers::view('libri/index', ['title' => 'Libri', 'libri' => $libri]);
    }

    public function createForm() {
        Auth::require();
        Helpers::view('libri/create', ['title' => 'Libri']);
    }

    public function store() {
        Auth::require();
        
        $data = [
            'titolo' => trim($_POST['titolo'] ?? ''),
            'autore' => trim($_POST['autore'] ?? ''),
            'isbn' => trim($_POST['isbn'] ?? ''),
            'editore' => trim($_POST['editore'] ?? ''),
            'anno' => !empty($_POST['anno']) ? (int)$_POST['anno'] : null,
            'genere' => trim($_POST['genere'] ?? ''),
            'note' => trim($_POST['note'] ?? ''),
            'stato' => trim($_POST['stato'] ?? 'Disponibile')
        ];

        if (empty($data['titolo'])) {
            // Semplice validazione
            Helpers::view('libri/create', ['error' => 'Il titolo è obbligatorio', 'data' => $data]);
            return;
        }

        $model = new Libro();
        $id = $model->create($data);
        
        // Generazione QR code
        \App\Services\QrCodeService::generateBookQr($id);

        Helpers::redirect('/libri');
    }

    public function show($id) {
        // Auth::require(); // Pubblico se serve, o protetto
        $model = new Libro();
        $libro = $model->find($id);
        
        if (!$libro) {
            http_response_code(404);
            echo "Libro non trovato";
            return;
        }

        // Assicura QR
        $qrRelative = \App\Services\QrCodeService::generateBookQr($id);

        // Recupera dati prestito se attivo
        $activeLoan = null;
        if (($libro['stato'] ?? '') === 'In Prestito' && !empty($libro['prestito_student_id'])) {
            $studentModel = new \App\Models\Student();
            $student = $studentModel->find($libro['prestito_student_id']);
            if ($student) {
                $activeLoan = [
                    'first_name' => $student['first_name'],
                    'last_name' => $student['last_name'],
                    'data_inizio_prestito' => $libro['prestito_data_inizio'],
                    'data_fine_prestito' => $libro['prestito_data_fine'],
                    'condizioni_libro' => $libro['prestito_condizioni']
                ];
            }
        }

        Helpers::view('libri/show', ['title' => 'Libri', 'libro' => $libro, 'qrPath' => $qrRelative, 'activeLoan' => $activeLoan]);
    }
    
    public function editForm($id) {
        Auth::require();
        $model = new Libro();
        $libro = $model->find($id);
        
        if (!$libro) {
            http_response_code(404);
            echo "Libro non trovato";
            return;
        }

        $students = (new \App\Models\Student())->all(['active' => 1]);

        Helpers::view('libri/edit', ['title' => 'Libri', 'libro' => $libro, 'students' => $students]);
    }

    public function update($id) {
        Auth::require();
        $model = new Libro();
        $currentBook = $model->find($id);

        if (!$currentBook) {
            http_response_code(404);
            return;
        }
        
        $data = [
            'titolo' => trim($_POST['titolo'] ?? ''),
            'autore' => trim($_POST['autore'] ?? ''),
            'isbn' => trim($_POST['isbn'] ?? ''),
            'editore' => trim($_POST['editore'] ?? ''),
            'anno' => !empty($_POST['anno']) ? (int)$_POST['anno'] : null,
            'genere' => trim($_POST['genere'] ?? ''),
            'note' => trim($_POST['note'] ?? ''),
            'stato' => trim($_POST['stato'] ?? 'Disponibile')
        ];

        // Gestione campi prestito
        if ($data['stato'] === 'In Prestito') {
            $studentId = !empty($_POST['prestito_student_id']) ? (int)$_POST['prestito_student_id'] : null;
            $dataInizio = $_POST['prestito_data_inizio'] ?? null;
            
            // Validazione obbligatoria per prestito
            if (!$studentId || !$dataInizio) {
                $students = (new \App\Models\Student())->all(['active' => 1]);
                Helpers::view('libri/edit', [
                    'libro' => array_merge($currentBook, $data, $_POST), 
                    'students' => $students,
                    'error' => 'Per mettere un libro in prestito devi selezionare un utente e una data di inizio.'
                ]);
                return;
            }

            // Calcolo limiti data
            $maxDate = date('Y-m-d', strtotime($dataInizio . ' + 30 days'));
            $userDateFine = $_POST['prestito_data_fine'] ?? null;

            // Usa la data utente se valida (>= inizio e <= max), altrimenti usa max
            if ($userDateFine && $userDateFine >= $dataInizio && $userDateFine <= $maxDate) {
                $dataFine = $userDateFine;
            } else {
                $dataFine = $maxDate;
            }

            // Validazione: Max 2 prestiti per utente
            // Se l'utente è cambiato o se è un nuovo prestito (prima era Disponibile), controlla il limite
            // Se stiamo aggiornando lo stesso prestito (stesso user, libro già in prestito), non serve contare questo libro come "aggiuntivo"
            // Ma countActiveLoans conta TUTTI i libri in prestito di quell'utente.
            
            $activeLoans = $model->countActiveLoans($studentId);
            
            // Se questo libro era già in prestito A QUESTO UTENTE, non devo contarlo come "nuovo" nel blocco
            $isSameLoan = ($currentBook['stato'] === 'In Prestito' && $currentBook['prestito_student_id'] == $studentId);
            
            // Blocco: se lo studente ha almeno un prestito scaduto non restituito, non può prendere altri
            $hasOverdue = $model->hasOverdueLoans($studentId);
            if (!$isSameLoan && $hasOverdue) {
                $students = (new \App\Models\Student())->all(['active' => 1]);
                Helpers::view('libri/edit', [
                    'libro' => array_merge($currentBook, $data, $_POST), 
                    'students' => $students,
                    'error' => 'Lo studente selezionato ha prestiti scaduti non restituiti: non può prendere altri libri.'
                ]);
                return;
            }
            
            if (!$isSameLoan && $activeLoans >= 2) {
                $students = (new \App\Models\Student())->all(['active' => 1]);
                Helpers::view('libri/edit', [
                    'libro' => array_merge($currentBook, $data, $_POST), 
                    'students' => $students,
                    'error' => 'L\'utente selezionato ha già 2 libri in prestito (massimo consentito).'
                ]);
                return;
            }

            // Un libro non può essere messo in prestito se è già in prestito? 
            // Qui stiamo modificando. Se era già in prestito e cambiamo utente, è come se lo restituissimo e lo dessimo a un altro.
            // La regola "non può essere messo in prestito se è già in prestito" vale per la CREAZIONE di un nuovo prestito su un libro occupato.
            // Qui stiamo gestendo lo stato del libro. Se l'admin decide di cambiare assegnatario, lo può fare.

            $data['prestito_student_id'] = $studentId;
            $data['prestito_data_inizio'] = $dataInizio;
            $data['prestito_data_fine'] = $dataFine;
            $data['prestito_condizioni'] = trim($_POST['prestito_condizioni'] ?? '');

        } else {
            // Se disponibile, resetta i campi prestito
            $data['prestito_student_id'] = null;
            $data['prestito_data_inizio'] = null;
            $data['prestito_data_fine'] = null;
            $data['prestito_condizioni'] = null;
        }

        if (empty($data['titolo'])) {
            $students = (new \App\Models\Student())->all(['active' => 1]);
            Helpers::view('libri/edit', ['libro' => $currentBook, 'students' => $students, 'error' => 'Il titolo è obbligatorio']);
            return;
        }

        $model->update($id, $data);
        Helpers::redirect('/libri');
    }

    public function delete($id) {
        Auth::require();
        $model = new Libro();
        $model->delete($id);
        Helpers::redirect('/libri');
    }
    
    // API endpoint for ISBN lookup (called via AJAX)
    public function lookupIsbn() {
        // Auth::require(); // Opzionale per questo, ma meglio averla
        header('Content-Type: application/json');
        
        $isbn = $_GET['isbn'] ?? '';
        if (empty($isbn)) {
            echo json_encode(['found' => false]);
            return;
        }

        // Pulisci ISBN
        $isbn = preg_replace('/[^0-9X]/', '', strtoupper($isbn));
        
        // OpenLibrary API
        $url = "https://openlibrary.org/api/books?bibkeys=ISBN:{$isbn}&jscmd=data&format=json";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // In locale a volte serve
        $response = curl_exec($ch);
        curl_close($ch);
        
        if ($response) {
            $data = json_decode($response, true);
            $key = "ISBN:{$isbn}";
            if (isset($data[$key])) {
                $book = $data[$key];
                $result = [
                    'found' => true,
                    'titolo' => $book['title'] ?? '',
                    'autore' => isset($book['authors'][0]['name']) ? $book['authors'][0]['name'] : '',
                    'editore' => isset($book['publishers'][0]['name']) ? $book['publishers'][0]['name'] : '',
                    'anno' => isset($book['publish_date']) ? (int)preg_replace('/[^0-9]/', '', $book['publish_date']) : '',
                    'genere' => '' // OpenLibrary genres are often complex objects
                ];
                echo json_encode($result);
                return;
            }
        }
        
        // 2. Fallback: Google Books API
        $urlGoogle = "https://www.googleapis.com/books/v1/volumes?q=isbn:{$isbn}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $urlGoogle);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $responseGoogle = curl_exec($ch);
        curl_close($ch);
        
        if ($responseGoogle) {
            $dataG = json_decode($responseGoogle, true);
            if (isset($dataG['items'][0]['volumeInfo'])) {
                $info = $dataG['items'][0]['volumeInfo'];
                $result = [
                    'found' => true,
                    'titolo' => $info['title'] ?? '',
                    'autore' => isset($info['authors'][0]) ? $info['authors'][0] : '',
                    'editore' => $info['publisher'] ?? '',
                    'anno' => isset($info['publishedDate']) ? (int)substr($info['publishedDate'], 0, 4) : '',
                    'genere' => isset($info['categories'][0]) ? $info['categories'][0] : ''
                ];
                echo json_encode($result);
                return;
            }
        }
        
        echo json_encode(['found' => false]);
    }
}
