<?php
namespace App\Models;

class Libro extends Model {
    public function __construct() {
        parent::__construct();
        $this->ensureTable();
    }

    private function ensureTable() {
        $sql = "CREATE TABLE IF NOT EXISTS libri (
            id INT AUTO_INCREMENT PRIMARY KEY,
            titolo VARCHAR(255) NOT NULL,
            autore VARCHAR(255),
            isbn VARCHAR(20),
            editore VARCHAR(255),
            anno INT,
            genere VARCHAR(100),
            note TEXT,
            stato VARCHAR(50) DEFAULT 'Disponibile'
        )";
        $this->pdo->exec($sql);
        
        try { $this->pdo->exec("ALTER TABLE libri ADD COLUMN note TEXT"); } catch (\Throwable $e) {}
        try { $this->pdo->exec("ALTER TABLE libri ADD COLUMN stato VARCHAR(50) DEFAULT 'Disponibile'"); } catch (\Throwable $e) {}
        try { $this->pdo->exec("ALTER TABLE libri ADD COLUMN prestito_student_id INT NULL"); } catch (\Throwable $e) {}
        try { $this->pdo->exec("ALTER TABLE libri ADD COLUMN prestito_data_inizio DATE NULL"); } catch (\Throwable $e) {}
        try { $this->pdo->exec("ALTER TABLE libri ADD COLUMN prestito_data_fine DATE NULL"); } catch (\Throwable $e) {}
        try { $this->pdo->exec("ALTER TABLE libri ADD COLUMN prestito_condizioni TEXT NULL"); } catch (\Throwable $e) {}
    }

    public function all() {
        $sql = "SELECT o.*, s.first_name, s.last_name 
                FROM libri o 
                LEFT JOIN students s ON o.prestito_student_id = s.id 
                ORDER BY o.titolo";
        $st = $this->pdo->query($sql);
        return $st->fetchAll();
    }

    public function countActiveLoans($studentId) {
        $st = $this->pdo->prepare("SELECT COUNT(*) FROM libri WHERE prestito_student_id = ? AND stato = 'In Prestito'");
        $st->execute([$studentId]);
        return $st->fetchColumn();
    }
    
    public function hasOverdueLoans($studentId) {
        $st = $this->pdo->prepare("SELECT COUNT(*) FROM libri WHERE prestito_student_id = ? AND stato = 'In Prestito' AND prestito_data_fine IS NOT NULL AND prestito_data_fine < CURDATE()");
        $st->execute([$studentId]);
        return ((int)$st->fetchColumn()) > 0;
    }

    public function find($id) {
        $st = $this->pdo->prepare('SELECT o.*, s.first_name, s.last_name, s.email 
                                   FROM libri o 
                                   LEFT JOIN students s ON o.prestito_student_id = s.id 
                                   WHERE o.id=?');
        $st->execute([$id]);
        return $st->fetch();
    }

    public function findByIsbn($isbn) {
        $st = $this->pdo->prepare('SELECT * FROM libri WHERE isbn=?');
        $st->execute([$isbn]);
        return $st->fetch();
    }

    public function create($data) {
        $st = $this->pdo->prepare('INSERT INTO libri (titolo, autore, isbn, editore, anno, genere, note, stato) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $st->execute([
            $data['titolo'],
            $data['autore'] ?? null,
            $data['isbn'] ?? null,
            $data['editore'] ?? null,
            $data['anno'] ?? null,
            $data['genere'] ?? null,
            $data['note'] ?? null,
            $data['stato'] ?? 'Disponibile'
        ]);
        return $this->pdo->lastInsertId();
    }

    public function update($id, $data) {
        $st = $this->pdo->prepare('UPDATE libri SET 
            titolo=?, autore=?, isbn=?, editore=?, anno=?, genere=?, note=?, stato=?,
            prestito_student_id=?, prestito_data_inizio=?, prestito_data_fine=?, prestito_condizioni=?
            WHERE id=?');
        $st->execute([
            $data['titolo'],
            $data['autore'] ?? null,
            $data['isbn'] ?? null,
            $data['editore'] ?? null,
            $data['anno'] ?? null,
            $data['genere'] ?? null,
            $data['note'] ?? null,
            $data['stato'] ?? 'Disponibile',
            $data['prestito_student_id'] ?? null,
            $data['prestito_data_inizio'] ?? null,
            $data['prestito_data_fine'] ?? null,
            $data['prestito_condizioni'] ?? null,
            $id
        ]);
    }

    public function delete($id) {
        $st = $this->pdo->prepare('DELETE FROM libri WHERE id=?');
        $st->execute([$id]);
    }

    public function updateStatus($id, $status) {
        $st = $this->pdo->prepare('UPDATE libri SET stato=? WHERE id=?');
        $st->execute([$status, $id]);
    }
}
