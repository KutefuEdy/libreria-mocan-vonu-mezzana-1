<?php
namespace App\Services;

use App\Core\Helpers;

class QrCodeService
{
  public static function generateBookQr(int $id): string
  {
    $conf = require dirname(__DIR__) . '/config.php';
    $externalBase = $conf['app']['qr_external_base'] ?? null;
    $qrPath = $conf['app']['qr_path'] ?? '/qr_book.php?code=';
    $code = 'CP-' . str_pad((string)$id, 6, '0', STR_PAD_LEFT);
    if ($externalBase) {
      $url = rtrim($externalBase, '/') . $qrPath . urlencode($code);
    } else {
      $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
      $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
      $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
      $url = $protocol . $host . rtrim($scriptDir, '/') . $qrPath . urlencode($code);
    }
    
    $basePath = dirname(__DIR__, 2);
    $dir = $basePath . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'qrcodes';
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    
    $filename = 'libro_' . $id . '.svg';
    $filePath = $dir . DIRECTORY_SEPARATOR . $filename;
    $sigPath = $dir . DIRECTORY_SEPARATOR . 'libro_' . $id . '.sig';
    
    // Se il QR esiste già e la signature coincide con l'URL corrente, non rigenerare
    if (file_exists($filePath) && file_exists($sigPath)) {
      $prev = @file_get_contents($sigPath);
      if (is_string($prev) && trim($prev) === $url) {
        return 'public/qrcodes/' . $filename;
      }
    }
    
    self::createQrFile($url, $filePath, $basePath);
    // Salva la signature dell'URL per evitare rigenerazioni inutili
    @file_put_contents($sigPath, $url);
    return 'public/qrcodes/' . $filename;
  }

  public static function generateBookQrByCode(string $code): string
  {
    $conf = require dirname(__DIR__) . '/config.php';
    $externalBase = $conf['app']['qr_external_base'] ?? null;
    $qrPath = $conf['app']['qr_path'] ?? '/qr_book.php?code=';
    if ($externalBase) {
      $url = rtrim($externalBase, '/') . $qrPath . urlencode($code);
    } else {
      $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
      $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
      $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
      $url = $protocol . $host . rtrim($scriptDir, '/') . $qrPath . urlencode($code);
    }
    $basePath = dirname(__DIR__, 2);
    $dir = $basePath . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'qrcodes';
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $safe = preg_replace('/[^A-Za-z0-9_\-]/', '_', $code);
    $filename = 'libro_' . $safe . '.svg';
    $filePath = $dir . DIRECTORY_SEPARATOR . $filename;
    self::createQrFile($url, $filePath, $basePath);
    return 'public/qrcodes/' . $filename;
  }

  private static function createQrFile(string $url, string $filePath, string $basePath): void
  {
    if (empty($url)) return;

    // 1. Try phpqrcode (preferred) - USING SVG to avoid GD dependency
    $libPath = $basePath . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'libs' . DIRECTORY_SEPARATOR . 'phpqrcode.php';
    if (file_exists($libPath)) {
        require_once $libPath;
        if (class_exists('QRcode')) {
             ob_start();
             try {
                 // QR_ECLEVEL_L = 0, size 4 (pixel per point), margin 2
                 // SVG does not use GD, so it works even if extension=gd is disabled
                 \QRcode::svg($url, $filePath, 0, 4, 2); 
             } catch (\Throwable $e) {
                 error_log('QR Gen (phpqrcode) Error: ' . $e->getMessage());
             }
             ob_end_clean();
             
             if (file_exists($filePath) && filesize($filePath) > 0) {
                 return;
             }
        }
    }

    // Fallbacks removed as we are using SVG with phpqrcode which doesn't require GD or external dependencies.
    error_log('QR Code generation failed: phpqrcode library not found or failed.');
  }
}
