<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-warning text-white">
                <h4 class="mb-0">Modifica Libro</h4>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="<?php echo \App\Core\Helpers::url('/libri/' . $libro['id'] . '/update'); ?>">
                    <input type="hidden" name="csrf" value="<?php echo \App\Core\CSRF::token(); ?>">
                    
                    <div class="mb-4">
                        <label class="form-label">Aggiorna dati da ISBN</label>
                        <div class="input-group">
                            <input type="text" id="isbn_search" class="form-control" placeholder="Inserisci ISBN per sovrascrivere i dati">
                            <button type="button" class="btn btn-secondary" id="btn_search_isbn">Cerca e Compila</button>
                        </div>
                    </div>

                    <hr>

                    <div class="mb-3">
                        <label for="isbn" class="form-label">ISBN</label>
                        <input type="text" class="form-control" id="isbn" name="isbn" value="<?php echo htmlspecialchars($libro['isbn'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="titolo" class="form-label">Titolo *</label>
                        <input type="text" class="form-control" id="titolo" name="titolo" required value="<?php echo htmlspecialchars($libro['titolo'] ?? ''); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="autore" class="form-label">Autore</label>
                            <input type="text" class="form-control" id="autore" name="autore" value="<?php echo htmlspecialchars($libro['autore'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editore" class="form-label">Editore</label>
                            <input type="text" class="form-control" id="editore" name="editore" value="<?php echo htmlspecialchars($libro['editore'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="anno" class="form-label">Anno</label>
                            <input type="number" class="form-control" id="anno" name="anno" value="<?php echo htmlspecialchars($libro['anno'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="genere" class="form-label">Genere</label>
                            <input type="text" class="form-control" id="genere" name="genere" value="<?php echo htmlspecialchars($libro['genere'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="note" class="form-label">Note</label>
                        <textarea class="form-control" id="note" name="note" rows="3"><?php echo htmlspecialchars($libro['note'] ?? ''); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="stato" class="form-label">Stato</label>
                        <select class="form-select" id="stato" name="stato">
                            <option value="Disponibile" <?php echo ($libro['stato'] ?? '') === 'Disponibile' ? 'selected' : ''; ?>>Disponibile</option>
                            <option value="In Prestito" <?php echo ($libro['stato'] ?? '') === 'In Prestito' ? 'selected' : ''; ?>>In Prestito</option>
                            <option value="Perso" <?php echo ($libro['stato'] ?? '') === 'Perso' ? 'selected' : ''; ?>>Perso</option>
                        </select>
                    </div>

                    <!-- Sezione Prestito (Visibile solo se stato = In Prestito) -->
                    <div id="prestito_section" class="border p-3 mb-3 rounded bg-light" style="display: none;">
                        <h5 class="text-primary mb-3">Dettagli Prestito</h5>
                        
                        <div class="mb-3">
                            <label for="prestito_student_id" class="form-label">Utente a cui è stato prestato il libro *</label>
                            <select class="form-select" id="prestito_student_id" name="prestito_student_id">
                                <option value="">Seleziona Utente...</option>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?php echo $student['id']; ?>" <?php echo ($libro['prestito_student_id'] ?? '') == $student['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($student['last_name'] . ' ' . $student['first_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="prestito_data_inizio" class="form-label">Data Inizio *</label>
                                <input type="date" class="form-control" id="prestito_data_inizio" name="prestito_data_inizio" 
                                       value="<?php echo htmlspecialchars($libro['prestito_data_inizio'] ?? date('Y-m-d')); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="prestito_data_fine" class="form-label">Data Fine (Max +30gg)</label>
                                <input type="date" class="form-control" id="prestito_data_fine" name="prestito_data_fine"
                                       value="<?php echo htmlspecialchars($libro['prestito_data_fine'] ?? ''); ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="prestito_condizioni" class="form-label">Condizioni del libro</label>
                            <select class="form-select" id="prestito_condizioni" name="prestito_condizioni">
                                <option value="">Seleziona condizioni...</option>
                                <option value="buono" <?php echo ($libro['prestito_condizioni'] ?? '') === 'buono' ? 'selected' : ''; ?>>Buono</option>
                                <option value="discreto" <?php echo ($libro['prestito_condizioni'] ?? '') === 'discreto' ? 'selected' : ''; ?>>Discreto</option>
                                <option value="male" <?php echo ($libro['prestito_condizioni'] ?? '') === 'male' ? 'selected' : ''; ?>>Male</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo \App\Core\Helpers::url('/libri'); ?>" class="btn btn-outline-secondary">Annulla</a>
                        <button type="submit" class="btn btn-warning">Aggiorna Libro</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Gestione visibilità campi prestito
document.addEventListener('DOMContentLoaded', function() {
    const statoSelect = document.getElementById('stato');
    const prestitoSection = document.getElementById('prestito_section');
    const dataInizioInput = document.getElementById('prestito_data_inizio');
    const dataFineInput = document.getElementById('prestito_data_fine');

    function togglePrestito() {
        if (statoSelect.value === 'In Prestito') {
            prestitoSection.style.display = 'block';
            document.getElementById('prestito_student_id').setAttribute('required', 'required');
            document.getElementById('prestito_data_inizio').setAttribute('required', 'required');
            
            // Se data inizio vuota, metti oggi
            if (!dataInizioInput.value) {
                dataInizioInput.valueAsDate = new Date();
                calcDataFine();
            }
        } else {
            prestitoSection.style.display = 'none';
            document.getElementById('prestito_student_id').removeAttribute('required');
            document.getElementById('prestito_data_inizio').removeAttribute('required');
        }
    }

    function calcDataFine() {
        if (dataInizioInput.value) {
            const startDate = new Date(dataInizioInput.value);
            const maxDate = new Date(startDate);
            maxDate.setDate(startDate.getDate() + 30);
            
            const minDateStr = startDate.toISOString().split('T')[0];
            const maxDateStr = maxDate.toISOString().split('T')[0];

            dataFineInput.min = minDateStr;
            dataFineInput.max = maxDateStr;

            // Se vuoto o fuori range, imposta a max (default)
            // L'utente ha chiesto di poter scegliere, ma mettiamo un default sensato
            if (!dataFineInput.value || dataFineInput.value < minDateStr || dataFineInput.value > maxDateStr) {
                dataFineInput.value = maxDateStr;
            }
        } else {
            dataFineInput.value = '';
            dataFineInput.removeAttribute('min');
            dataFineInput.removeAttribute('max');
        }
    }

    statoSelect.addEventListener('change', togglePrestito);
    dataInizioInput.addEventListener('change', calcDataFine);

    // Init
    togglePrestito();
    if (statoSelect.value === 'In Prestito') {
        calcDataFine();
    }
});

document.getElementById('btn_search_isbn').addEventListener('click', function() {
    const isbn = document.getElementById('isbn_search').value.trim();
    if (!isbn) return;

    const btn = this;
    const originalText = btn.textContent;
    btn.textContent = 'Cercando...';
    btn.disabled = true;

    fetch('<?php echo \App\Core\Helpers::url("/libri/lookup-isbn?isbn="); ?>' + encodeURIComponent(isbn))
        .then(response => response.json())
        .then(data => {
            if (data.found) {
                document.getElementById('isbn').value = isbn;
                if (data.titolo) document.getElementById('titolo').value = data.titolo;
                if (data.autore) document.getElementById('autore').value = data.autore;
                if (data.editore) document.getElementById('editore').value = data.editore;
                if (data.anno) document.getElementById('anno').value = data.anno;
                if (data.genere) document.getElementById('genere').value = data.genere;
                // alert('Dati trovati e compilati!');
            } else {
                alert('Nessun dato trovato per questo ISBN.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Errore durante la ricerca.');
        })
        .finally(() => {
            btn.textContent = originalText;
            btn.disabled = false;
        });
});
</script>
