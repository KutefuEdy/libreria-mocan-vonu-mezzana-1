<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Nuovo Libro</h4>
            </div>
            <div class="card-body">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="<?php echo \App\Core\Helpers::url('/libri/store'); ?>">
                    <input type="hidden" name="csrf" value="<?php echo \App\Core\CSRF::token(); ?>">
                    
                    <div class="mb-4">
                        <label class="form-label">Ricerca rapida da ISBN</label>
                        <div class="input-group">
                            <input type="text" id="isbn_search" class="form-control" placeholder="Inserisci ISBN (es. 9788804668237)">
                            <button type="button" class="btn btn-secondary" id="btn_search_isbn">Cerca</button>
                        </div>
                        <small class="text-muted">Se l'ISBN viene trovato, i campi sottostanti verranno compilati automaticamente.</small>
                    </div>

                    <hr>

                    <div class="mb-3">
                        <label for="isbn" class="form-label">ISBN</label>
                        <input type="text" class="form-control" id="isbn" name="isbn" value="<?php echo htmlspecialchars($data['isbn'] ?? ''); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="titolo" class="form-label">Titolo *</label>
                        <input type="text" class="form-control" id="titolo" name="titolo" required value="<?php echo htmlspecialchars($data['titolo'] ?? ''); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="autore" class="form-label">Autore</label>
                            <input type="text" class="form-control" id="autore" name="autore" value="<?php echo htmlspecialchars($data['autore'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editore" class="form-label">Editore</label>
                            <input type="text" class="form-control" id="editore" name="editore" value="<?php echo htmlspecialchars($data['editore'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="anno" class="form-label">Anno</label>
                            <input type="number" class="form-control" id="anno" name="anno" value="<?php echo htmlspecialchars($data['anno'] ?? ''); ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="genere" class="form-label">Genere</label>
                            <input type="text" class="form-control" id="genere" name="genere" value="<?php echo htmlspecialchars($data['genere'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="note" class="form-label">Note</label>
                        <textarea class="form-control" id="note" name="note" rows="3"><?php echo htmlspecialchars($data['note'] ?? ''); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="stato" class="form-label">Stato</label>
                        <select class="form-select" id="stato" name="stato">
                            <option value="Disponibile" <?php echo ($data['stato'] ?? '') === 'Disponibile' ? 'selected' : ''; ?>>Disponibile</option>
                            <option value="In Prestito" <?php echo ($data['stato'] ?? '') === 'In Prestito' ? 'selected' : ''; ?>>In Prestito</option>
                            <option value="Perso" <?php echo ($data['stato'] ?? '') === 'Perso' ? 'selected' : ''; ?>>Perso</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo \App\Core\Helpers::url('/libri'); ?>" class="btn btn-outline-secondary">Annulla</a>
                        <button type="submit" class="btn btn-primary">Salva Libro</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('btn_search_isbn').addEventListener('click', function() {
    const isbn = document.getElementById('isbn_search').value.trim();
    if (!isbn) return;

    const btn = this;
    const originalText = btn.textContent;
    btn.textContent = 'Cercando...';
    btn.disabled = true;

    fetch('<?php echo \App\Core\Helpers::url("/libri/lookup-isbn?isbn="); ?>' + encodeURIComponent(isbn))
        .then(response => response.json())
        .then(data => {
            if (data.found) {
                document.getElementById('isbn').value = isbn;
                if (data.titolo) document.getElementById('titolo').value = data.titolo;
                if (data.autore) document.getElementById('autore').value = data.autore;
                if (data.editore) document.getElementById('editore').value = data.editore;
                if (data.anno) document.getElementById('anno').value = data.anno;
                if (data.genere) document.getElementById('genere').value = data.genere;
                // alert('Dati trovati e compilati!');
            } else {
                alert('Nessun dato trovato per questo ISBN.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Errore durante la ricerca.');
        })
        .finally(() => {
            btn.textContent = originalText;
            btn.disabled = false;
        });
});
</script>
