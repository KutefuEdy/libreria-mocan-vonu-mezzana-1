<?php
$title = "Dettaglio Libro: " . $libro['titolo'];
?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Dettaglio Libro</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h2 class="mb-3"><?php echo htmlspecialchars($libro['titolo']); ?></h2>
                            <h5 class="text-muted mb-4"><?php echo htmlspecialchars($libro['autore'] ?? 'Autore sconosciuto'); ?></h5>
                            
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <th style="width: 150px;">ISBN:</th>
                                        <td><?php echo htmlspecialchars($libro['isbn'] ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Editore:</th>
                                        <td><?php echo htmlspecialchars($libro['editore'] ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Anno:</th>
                                        <td><?php echo htmlspecialchars($libro['anno'] ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Genere:</th>
                                        <td><?php echo htmlspecialchars($libro['genere'] ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Stato:</th>
                                        <td>
                                            <span class="badge bg-<?php echo ($libro['stato'] ?? 'Disponibile') === 'Disponibile' ? 'success' : 'warning'; ?>">
                                                <?php echo htmlspecialchars($libro['stato'] ?? 'Disponibile'); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php if (!empty($libro['note'])): ?>
                                    <tr>
                                        <th>Note:</th>
                                        <td><?php echo nl2br(htmlspecialchars($libro['note'])); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>

                            <?php if (!empty($activeLoan)): ?>
                            <div class="border p-3 mb-3 rounded bg-light">
                                <h5 class="text-primary mb-3">Dettagli Prestito</h5>
                                
                                <div class="mb-3">
                                    <label class="form-label text-muted small mb-0">Utente</label>
                                    <div class="fw-bold"><?php echo htmlspecialchars($activeLoan['first_name'] . ' ' . $activeLoan['last_name']); ?></div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-muted small mb-0">Data Inizio</label>
                                        <div><?php echo htmlspecialchars($activeLoan['data_inizio_prestito']); ?></div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-muted small mb-0">Data Fine</label>
                                        <div class="<?php echo strtotime($activeLoan['data_fine_prestito']) < time() ? 'text-danger fw-bold' : ''; ?>">
                                            <?php echo htmlspecialchars($activeLoan['data_fine_prestito']); ?>
                                            <?php if (strtotime($activeLoan['data_fine_prestito']) < time()) echo ' (SCADUTO)'; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label text-muted small mb-0">Condizioni del libro</label>
                                    <div><?php echo !empty($activeLoan['condizioni_libro']) ? htmlspecialchars(ucfirst($activeLoan['condizioni_libro'])) : '-'; ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="col-md-4 text-center">
                            <div class="p-3 border rounded bg-light">
                                <label class="text-muted small mb-2">QR Code Libro</label>
                                <?php if (!empty($qrPath)): ?>
                                    <img src="<?php echo \App\Core\Helpers::url('/' . $qrPath); ?>" alt="QR Code" class="img-fluid mb-2" style="max-width: 200px;">
                                    <br>
                                    <small class="text-muted">Scannerizza per i dettagli</small>
                                <?php else: ?>
                                    <div class="alert alert-warning">QR non disponibile</div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-grid gap-2 mt-4">
                                <?php if (\App\Core\Auth::isAdmin()): ?>
                                <a href="<?php echo \App\Core\Helpers::url('/libri/' . $libro['id'] . '/edit'); ?>" class="btn btn-warning">
                                    Modifica Libro
                                </a>
                                <!-- <a href="#" class="btn btn-success">
                                    + Aggiungi Copia (Disabilitato)
                                </a> -->
                                <?php endif; ?>
                                <a href="<?php echo \App\Core\Helpers::url('/libri'); ?>" class="btn btn-outline-primary">
                                    Torna alla lista
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
