<!--
  Vista: libri/index.php
  Scopo: Elenco libri con layout in stile "studenti"
-->
<h3 class="mb-3">Gestione Libri</h3>
<?php
$inPrestito = 0;
$disponibili = 0;
foreach ($libri as $l) {
    if (($l['stato'] ?? 'Disponibile') === 'In Prestito') {
        $inPrestito++;
    } else {
        $disponibili++;
    }
}
?>
<div class="row mb-3">
  <div class="col-md-4">
    <div class="card bg-primary-subtle">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-center round-48 rounded text-bg-primary flex-shrink-0 mb-3 mx-auto">
          <iconify-icon icon="solar:book-2-line-duotone" class="icon-24 text-white"></iconify-icon>
        </div>
        <h5 class="card-title fw-semibold text-center mb-1">Totale Libri</h5>
        <h2 class="card-text text-primary text-center"><?php echo count($libri); ?></h2>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card bg-warning-subtle">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-center round-48 rounded text-bg-warning flex-shrink-0 mb-3 mx-auto">
          <iconify-icon icon="solar:bookmark-circle-line-duotone" class="icon-24 text-white"></iconify-icon>
        </div>
        <h5 class="card-title fw-semibold text-center mb-1">In Prestito</h5>
        <h2 class="card-text text-warning text-center"><?php echo $inPrestito; ?></h2>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card bg-success-subtle">
      <div class="card-body">
        <div class="d-flex align-items-center justify-content-center round-48 rounded text-bg-success flex-shrink-0 mb-3 mx-auto">
          <iconify-icon icon="solar:check-circle-line-duotone" class="icon-24 text-white"></iconify-icon>
        </div>
        <h5 class="card-title fw-semibold text-center mb-1">Disponibili</h5>
        <h2 class="card-text text-success text-center"><?php echo $disponibili; ?></h2>
      </div>
    </div>
  </div>
</div>

<div class="d-flex justify-content-end mb-3 gap-2">
  <?php if (\App\Core\Auth::isAdmin()): ?>
    <a class="btn btn-primary" href="<?php echo \App\Core\Helpers::url('/libri/create'); ?>">Nuovo Libro</a>
  <?php endif; ?>
</div>

<div class="table-responsive">
  <table id="libriTable" class="table table-striped table-bordered text-nowrap">
    <thead class="table-light">
      <tr>
        <th>Titolo</th>
        <th>Autore</th>
        <th>ISBN</th>
        <th>Stato</th>
        <th>Azioni</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($libri as $libro) { ?>
        <tr>
          <td><?php echo htmlspecialchars($libro['titolo']); ?></td>
          <td><?php echo htmlspecialchars($libro['autore'] ?? '-'); ?></td>
          <td><?php echo htmlspecialchars($libro['isbn'] ?? '-'); ?></td>
          <td>
            <?php 
              $stato = $libro['stato'] ?? 'Disponibile';
              $badgeClass = ($stato === 'Disponibile') ? 'bg-success' : 'bg-warning';
              echo '<span class="badge ' . $badgeClass . '">' . htmlspecialchars($stato) . '</span>';
            ?>
          </td>
          <td>
            <a class="btn btn-sm btn-outline-info" href="<?php echo \App\Core\Helpers::url('/libri/show/' . $libro['id']); ?>">Visualizza</a>
            
            <?php if (\App\Core\Auth::isAdmin()): ?>
              <a class="btn btn-sm btn-outline-primary" href="<?php echo \App\Core\Helpers::url('/libri/' . $libro['id'] . '/edit'); ?>">Modifica</a>
              <button type="button" class="btn btn-sm btn-outline-danger ms-1" data-bs-toggle="modal" data-bs-target="#deleteLibroModal" data-id="<?php echo $libro['id']; ?>" data-title="<?php echo htmlspecialchars($libro['titolo']); ?>">Elimina</button>
            <?php endif; ?>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function(){
    var t = document.getElementById('libriTable');
    if (!t || !window.jQuery) return;
    var $ = window.jQuery;
    
    // Inizializzazione DataTable
    var dt = $(t).DataTable({
      responsive: true,
      deferRender: true,
      autoWidth: false,
      pageLength: 10,
      lengthMenu: [[10, 25, 50, 100, 200, -1], [10, 25, 50, 100, 200, "All"]],
      order: [], // Nessun ordinamento iniziale forzato
      columnDefs: [
        { targets: -1, orderable: false, searchable: false } // Colonna Azioni
      ],
      dom: 'B<"d-flex justify-content-end align-items-center"f>rt<"d-flex justify-content-between align-items-center mt-2"l i p>',
      buttons: [
        { extend: 'copy', text: 'Copia', className: 'btn btn-outline-primary' },
        { extend: 'csv', text: 'CSV', className: 'btn btn-outline-primary' },
        { extend: 'excel', text: 'Excel', className: 'btn btn-outline-primary' },
        { extend: 'pdf', text: 'PDF', className: 'btn btn-outline-primary' },
        { extend: 'print', text: 'Stampa', className: 'btn btn-outline-primary' },
        { extend: 'colvis', text: 'Colonne', className: 'btn btn-outline-primary' }
      ],
      language: {
        search: 'Cerca:',
        lengthMenu: 'Mostra _MENU_ righe',
        info: 'Mostra da _START_ a _END_ di _TOTAL_',
        infoEmpty: 'Nessun record',
        zeroRecords: 'Nessun risultato trovato',
        loadingRecords: 'Caricamento...',
        processing: 'Elaborazione...',
        paginate: { first: 'Prima', last: 'Ultima', next: 'Successiva', previous: 'Precedente' }
      }
    });

    // Stilizzazione campi DataTables per Bootstrap
    var wid = t.id + '_search';
    var wrap = $(t).closest('.dataTables_wrapper');
    var lbl = wrap.find('.dataTables_filter label');
    var inp = lbl.find('input');
    inp.attr({ id: wid, name: wid, 'aria-label': 'Cerca libri' });
    lbl.attr('for', wid);
    
    var lsel = wrap.find('.dataTables_length select');
    var lid = t.id + '_length';
    lsel.attr({ id: lid, name: lid, 'aria-label': 'Numero righe' });
  });
</script>

<!-- Modal Eliminazione -->
<div class="modal fade" id="deleteLibroModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="deleteLibroForm" action="" method="post">
        <input type="hidden" name="csrf" value="<?php echo \App\Core\CSRF::token(); ?>">
        <div class="modal-header">
          <h5 class="modal-title">Conferma eliminazione</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Sei sicuro di voler eliminare il libro <strong id="delLibroTitle"></strong>?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
          <button type="submit" class="btn btn-danger">Elimina</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  var deleteModal = document.getElementById('deleteLibroModal');
  if (deleteModal) {
    deleteModal.addEventListener('show.bs.modal', function (e) {
      var btn = e.relatedTarget;
      var id = btn.getAttribute('data-id');
      var title = btn.getAttribute('data-title');
      
      // Imposta l'action del form
      document.getElementById('deleteLibroForm').setAttribute('action', '<?php echo \App\Core\Helpers::url('/libri/'); ?>' + id + '/delete');
      
      // Imposta il titolo nel messaggio
      document.getElementById('delLibroTitle').textContent = title || '';
    });
  }
</script>
