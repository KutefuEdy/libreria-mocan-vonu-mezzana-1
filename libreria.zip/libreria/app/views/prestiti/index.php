<h3 class="mb-3">Prestiti Attivi</h3>
<div class="card">
  <div class="card-body">
    <div class="table-responsive">
      <table id="prestitiTable" class="table table-striped table-bordered text-nowrap">
        <thead class="table-light">
          <tr>
            <th>Libro</th>
            <th>Utente</th>
            <th>Data Inizio</th>
            <th>Data Fine</th>
            <th>Stato</th>
            <th>Azioni</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($prestiti as $p) { 
            $stato = $p['stato'] ?? 'Disponibile';
            $isScaduto = ($stato === 'In Prestito' && !empty($p['prestito_data_fine']) && strtotime($p['prestito_data_fine']) < time());
            $badgeClass = $isScaduto ? 'bg-danger' : ($stato === 'In Prestito' ? 'bg-warning' : 'bg-success');
            ?>
            <tr>
              <td><?php echo htmlspecialchars($p['titolo']); ?></td>
              <td><?php echo htmlspecialchars(trim(($p['last_name'] ?? '').' '.($p['first_name'] ?? '')) ?: '-'); ?></td>
              <td><?php echo htmlspecialchars($p['prestito_data_inizio'] ?? '-'); ?></td>
              <td>
                <?php echo htmlspecialchars($p['prestito_data_fine'] ?? '-'); ?>
                <?php if ($isScaduto) { ?><span class="badge bg-danger ms-2">SCADUTO</span><?php } ?>
              </td>
              <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($stato); ?></span></td>
              <td>
                <a class="btn btn-outline-primary btn-sm" href="<?php echo \App\Core\Helpers::url('/libri/'.$p['id']); ?>">Dettagli</a>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function(){
  var t = document.getElementById('prestitiTable');
  if (!window.jQuery || !jQuery.fn || !jQuery.fn.dataTable) return;
  jQuery(t).DataTable({
    responsive: true,
    deferRender: true,
    autoWidth: false,
    pageLength: 10,
    lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Tutti"]],
    order: [],
    dom: 'B<"d-flex justify-content-end align-items-center"f>rt<"d-flex justify-content-between align-items-center mt-2"l i p>',
    buttons: [
      { extend: 'copy', text: 'Copia', className: 'btn btn-outline-primary' },
      { extend: 'csv', text: 'CSV', className: 'btn btn-outline-primary' },
      { extend: 'excel', text: 'Excel', className: 'btn btn-outline-primary' },
      { extend: 'pdf', text: 'PDF', className: 'btn btn-outline-primary' },
      { extend: 'print', text: 'Stampa', className: 'btn btn-outline-primary' },
      { extend: 'colvis', text: 'Colonne', className: 'btn btn-outline-primary' }
    ],
    language: {
      search: 'Cerca:',
      lengthMenu: 'Mostra _MENU_ righe',
      info: 'Mostra da _START_ a _END_ di _TOTAL_',
      infoEmpty: 'Nessun record',
      zeroRecords: 'Nessun risultato trovato',
      loadingRecords: 'Caricamento...',
      processing: 'Elaborazione...',
      paginate: { first: 'Prima', last: 'Ultima', next: 'Successiva', previous: 'Precedente' }
    }
  });
  var wid = t.id + '_search';
  var wrap = jQuery(t).closest('.dataTables_wrapper');
  var lbl = wrap.find('.dataTables_filter label');
  var inp = lbl.find('input');
  inp.attr({ id: wid, name: wid, 'aria-label': 'Cerca prestiti' });
  lbl.attr('for', wid);
  var lsel = wrap.find('.dataTables_length select');
  var lid = t.id + '_length';
  lsel.attr({ id: lid, name: lid, 'aria-label': 'Numero righe' });
});
</script>
