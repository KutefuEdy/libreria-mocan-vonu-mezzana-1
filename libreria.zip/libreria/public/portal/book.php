<?php
$vendorAutoload = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
if (is_file($vendorAutoload)) { require $vendorAutoload; }
spl_autoload_register(function($class){
  $prefix = 'App\\';
  if (strncmp($prefix, $class, strlen($prefix)) !== 0) return;
  $path = dirname(__DIR__, 2) . '/app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
  if (file_exists($path)) require $path;
});

use App\Core\Helpers;

$code = isset($_GET['code']) ? trim($_GET['code']) : '';
$id = null;
if (preg_match('/(\d+)$/', $code, $m)) { $id = (int)ltrim($m[1], '0'); }
$pdo = \App\Core\DB::conn();
$book = null;
if ($id) {
  $st = $pdo->prepare('SELECT * FROM libri WHERE id = ?');
  $st->execute([$id]);
  $book = $st->fetch();
}

$baseUrl = dirname($_SERVER['SCRIPT_NAME'], 3);
$baseUrl = $baseUrl === DIRECTORY_SEPARATOR ? '' : str_replace('\\', '/', $baseUrl);
?>
<!DOCTYPE html>
<html lang="it" dir="ltr" data-bs-theme="light" data-color-theme="Blue_Theme" data-layout="vertical">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $book ? htmlspecialchars($book['titolo']) : 'Libro non trovato'; ?> - Portale Pubblico</title>
  
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>/public/css/fonts-manrope.css" />
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>/public/css/styles.css" />
  <link rel="stylesheet" href="<?php echo $baseUrl; ?>/public/assets/css/app.css" />
  
  <style>
    body { background-color: #f4f7fb; font-family: 'Plus Jakarta Sans', sans-serif; }
    .portal-card { border: none; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden; }
    .portal-header { background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; padding: 40px 20px; text-align: center; }
    .portal-body { padding: 30px; background: white; }
    .section-title { font-weight: 700; color: #1e293b; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px; }
    .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
    .info-item .label { font-size: 0.8rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 5px; }
    .info-item .value { font-weight: 600; color: #334155; font-size: 1.05rem; }
    .badge-status { padding: 8px 16px; border-radius: 50px; font-weight: 600; font-size: 0.85rem; }
    .logo-container { margin-bottom: 20px; }
    .logo-container img { max-width: 250px; }
    .footer-text { text-align: center; color: #94a3b8; font-size: 0.85rem; margin-top: 30px; }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="text-center logo-container">
          <img src="<?php echo $baseUrl; ?>/public/images/logos/logo_v3_scuro.png" alt="Logo">
        </div>

        <div class="portal-card">
          <?php if ($book): ?>
            <div class="portal-header">
              <div class="mb-2">
                <iconify-icon icon="solar:book-2-bold-duotone" width="48" height="48" class="text-white opacity-75"></iconify-icon>
              </div>
              <h2 class="text-white fw-bold mb-1"><?php echo htmlspecialchars($book['titolo']); ?></h2>
              <p class="text-white opacity-75 mb-0"><?php echo htmlspecialchars($book['autore'] ?? 'Autore sconosciuto'); ?></p>
            </div>
            
            <div class="portal-body">
              <!-- Sezione Libro -->
              <div class="mb-5">
                <h5 class="section-title">
                  <iconify-icon icon="solar:info-circle-bold-duotone" class="text-primary"></iconify-icon>
                  Informazioni Opera
                </h5>
                <div class="info-grid">
                  <div class="info-item">
                    <div class="label">ISBN</div>
                    <div class="value"><?php echo htmlspecialchars($book['isbn'] ?? '-'); ?></div>
                  </div>
                  <div class="info-item">
                    <div class="label">Editore</div>
                    <div class="value"><?php echo htmlspecialchars($book['editore'] ?? '-'); ?></div>
                  </div>
                  <div class="info-item">
                    <div class="label">Anno</div>
                    <div class="value"><?php echo htmlspecialchars($book['anno'] ?? '-'); ?></div>
                  </div>
                  <div class="info-item">
                    <div class="label">Genere</div>
                    <div class="value"><?php echo htmlspecialchars($book['genere'] ?? '-'); ?></div>
                  </div>
                </div>
              </div>

              <!-- Sezione Copia -->
              <div class="mb-5">
                <h5 class="section-title">
                  <iconify-icon icon="solar:tag-bold-duotone" class="text-primary"></iconify-icon>
                  Dettagli Copia
                </h5>
                <div class="info-grid">
                  <div class="info-item">
                    <div class="label">Codice Copia</div>
                    <div class="value text-primary fw-bold"><?php echo htmlspecialchars($code ?: 'N/D'); ?></div>
                  </div>
                  <div class="info-item">
                    <div class="label">Posizione</div>
                    <div class="value"><?php echo !empty($book['posizione']) ? htmlspecialchars($book['posizione']) : '<span class="text-muted">Non specificata</span>'; ?></div>
                  </div>
                </div>
              </div>

              <!-- Sezione Stato -->
              <div>
                <h5 class="section-title">
                  <iconify-icon icon="solar:calendar-bold-duotone" class="text-primary"></iconify-icon>
                  Stato Attuale
                </h5>
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                  <div class="info-item">
                    <div class="label">Stato Libro</div>
                    <?php
                      $st = $book['stato'] ?? 'Disponibile';
                      $badgeClass = $st === 'In Prestito' ? 'bg-warning-subtle text-warning' : 'bg-success-subtle text-success';
                    ?>
                    <span class="badge-status <?php echo $badgeClass; ?>">
                      <iconify-icon icon="<?php echo $st === 'In Prestito' ? 'solar:clock-circle-bold' : 'solar:check-circle-bold'; ?>" class="align-middle me-1"></iconify-icon>
                      <?php echo htmlspecialchars($st); ?>
                    </span>
                  </div>
                  
                  <?php if ($book['stato'] === 'In Prestito' && !empty($book['prestito_data_fine'])): ?>
                    <div class="info-item">
                      <div class="label">Rientro Previsto</div>
                      <div class="value text-danger">
                        <?php echo htmlspecialchars(date('d/m/Y', strtotime($book['prestito_data_fine']))); ?>
                      </div>
                    </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php else: ?>
            <div class="portal-header bg-danger">
              <iconify-icon icon="solar:danger-bold-duotone" width="48" height="48" class="text-white"></iconify-icon>
              <h2 class="text-white fw-bold mt-2">Libro non trovato</h2>
            </div>
            <div class="portal-body text-center py-5">
              <p class="text-muted mb-4">Il codice copia <strong><?php echo htmlspecialchars($code); ?></strong> non corrisponde ad alcun libro nel nostro archivio.</p>
              <a href="javascript:history.back()" class="btn btn-outline-primary rounded-pill px-4">Torna indietro</a>
            </div>
          <?php endif; ?>
        </div>

        <div class="footer-text">
          &copy; <?php echo date('Y'); ?> Portale Pubblico Libreria - TechLab PC<br>
          <small>Sistema di gestione bibliotecaria digitale</small>
        </div>
      </div>
    </div>
  </div>

  <script src="<?php echo $baseUrl; ?>/public/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo $baseUrl; ?>/public/libs/iconify/iconify-icon.min.js"></script>
  <script>
    (function () {
      var u = '<?php echo $baseUrl; ?>/public/libs/iconify/solar.json';
      fetch(u, { credentials: 'omit' }).then(function (r) { return r.json(); }).then(function (col) {
        var api = window.Iconify || window.IconifyIcon;
        if (api && api.addCollection) { api.addCollection(col); }
      });
    })();
  </script>
</body>
</html>