<?php
$vendorAutoload = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
if (is_file($vendorAutoload)) {
  require $vendorAutoload;
}
spl_autoload_register(function($class){
  $prefix = 'App\\';
  if (strncmp($prefix, $class, strlen($prefix)) !== 0) return;
  $path = __DIR__ . '/../app/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
  if (file_exists($path)) require $path;
});
$code = isset($_GET['code']) ? trim($_GET['code']) : '';
$id = null;
if (preg_match('/(\d+)$/', $code, $m)) {
  $id = (int)ltrim($m[1], '0');
}
$pdo = \App\Core\DB::conn();
$book = null;
if ($id) {
  $st = $pdo->prepare('SELECT * FROM libri WHERE id = ?');
  $st->execute([$id]);
  $book = $st->fetch();
}
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? '';
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$absUrl = $scheme . $host . rtrim($scriptDir, '/') . '/qr_book.php?code=' . urlencode($code);
$basePath = dirname(__DIR__);
$qrDir = $basePath . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . 'qrcodes';
if (!is_dir($qrDir)) { mkdir($qrDir, 0775, true); }
$safe = $code !== '' ? preg_replace('/[^A-Za-z0-9_\-]/', '_', $code) : 'unknown';
$qrFile = $qrDir . DIRECTORY_SEPARATOR . 'qr_copy_' . $safe . '.png';
$libPath = $basePath . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'libs' . DIRECTORY_SEPARATOR . 'phpqrcode.php';
if (file_exists($libPath)) {
  require_once $libPath;
  if (class_exists('QRcode')) {
    \QRcode::png($absUrl, $qrFile, 0, 4, 2);
  }
}
$qrPublicPath = 'public/qrcodes/' . 'qr_copy_' . $safe . '.png';
?>
<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>QR Libro</title>
  <link rel="stylesheet" href="<?php echo htmlspecialchars(rtrim($scriptDir, '/') . '/css/styles.css'); ?>">
</head>
<body style="padding:20px;font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
  <div style="max-width:720px;margin:0 auto">
    <h1 style="margin-bottom:16px">Pagina Pubblica Libro</h1>
    <?php if ($book): ?>
      <div style="padding:12px;border:1px solid #ddd;border-radius:8px;margin-bottom:14px;background:#f8f9fa">
        <div style="font-weight:600;margin-bottom:8px">Dati del libro</div>
        <div style="margin-bottom:6px"><strong>Titolo:</strong> <?php echo htmlspecialchars($book['titolo'] ?? ''); ?></div>
        <div style="margin-bottom:6px"><strong>Autore:</strong> <?php echo htmlspecialchars($book['autore'] ?? ''); ?></div>
        <div style="margin-bottom:6px"><strong>ISBN:</strong> <?php echo htmlspecialchars($book['isbn'] ?? '-'); ?></div>
        <div style="margin-bottom:6px"><strong>Editore:</strong> <?php echo htmlspecialchars($book['editore'] ?? '-'); ?></div>
        <div style="margin-bottom:6px"><strong>Anno:</strong> <?php echo htmlspecialchars($book['anno'] ?? '-'); ?></div>
        <div style="margin-bottom:6px"><strong>Genere:</strong> <?php echo htmlspecialchars($book['genere'] ?? '-'); ?></div>
      </div>

      <div style="padding:12px;border:1px solid #ddd;border-radius:8px;margin-bottom:14px;background:#f8f9fa">
        <div style="font-weight:600;margin-bottom:8px">Dati della copia</div>
        <div style="margin-bottom:6px"><strong>Codice copia:</strong> <?php echo htmlspecialchars($code); ?></div>
        <div style="margin-bottom:6px"><strong>Posizione in libreria:</strong> <?php echo !empty($book['posizione']) ? htmlspecialchars($book['posizione']) : 'Non disponibile'; ?></div>
      </div>

      <div style="padding:12px;border:1px solid #ddd;border-radius:8px;margin-bottom:14px;background:#f8f9fa">
        <div style="font-weight:600;margin-bottom:8px">Prestito</div>
        <div style="margin-bottom:6px"><strong>Stato prestito:</strong> <?php echo htmlspecialchars($book['stato'] ?? ''); ?></div>
        <div style="margin-bottom:6px"><strong>Data di rientro prevista:</strong> <?php echo ($book['stato'] === 'In Prestito' && !empty($book['prestito_data_fine'])) ? htmlspecialchars($book['prestito_data_fine']) : '-'; ?></div>
      </div>
    <?php else: ?>
      <div style="margin-bottom:8px"><strong>Codice copia:</strong> <?php echo htmlspecialchars($code); ?></div>
      <div style="margin-bottom:16px;color:#b00020">Libro non trovato</div>
    <?php endif; ?>
    <div style="margin-top:24px">
      <div style="margin-bottom:8px"><strong>QR Code (URL):</strong></div>
      <div style="margin-bottom:12px"><a href="<?php echo htmlspecialchars($absUrl); ?>" target="_blank"><?php echo htmlspecialchars($absUrl); ?></a></div>
      <?php if (file_exists($qrFile)): ?>
        <img src="<?php echo htmlspecialchars(rtrim($scriptDir, '/') . '/qrcodes/' . 'qr_copy_' . $safe . '.png'); ?>" alt="QR" style="width:220px;height:auto;border:1px solid #ddd;padding:8px;border-radius:8px">
      <?php else: ?>
        <div style="color:#b00020">Impossibile generare il QR</div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
