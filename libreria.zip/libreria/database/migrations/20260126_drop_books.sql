-- Rimozione tabelle non utilizzate per il modulo Libri
-- Esegue DROP in modo idempotente (non fallisce se la tabella non esiste)

DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS book;

