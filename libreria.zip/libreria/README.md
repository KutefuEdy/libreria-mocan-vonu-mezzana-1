Questo progetto è stato scritto velocemente per gestire l'azienda simulata del primo anno. Sarei molto felice se voleste studiarlo, modificarlo per quanto possibile e presentarlo ai ragazzi del primo anno come software di gestione utile ai loro scopi. Come nel caso della biblioteca anche qui sono partito dalle specifiche che sono diventate un prompt e poi codice (trovate le specifiche complete nella cartella docs).
Prendete questo progetto come esempio per i futuri sviluppi software: è scritto in php puro seguendo il pattern MVC (qui una spiegazione semplice : https://www.giuseppemaccario.com/it/come-costruire-un-semplice-framework-mvc-con-php/ - anche se qui utilizza il routing di symfony mentre io preferisco riscriverlo da capo)
Come al solito prima di modificarlo o utilizzarne una forma simile, dovete capire bene ogni singola linea di codice, altrimenti si arriverà facilmente ad un punto in cui non si potrà più andare avanti.
Come per gli altri progetti utilizzate github per lo sviluppo: questo vi consentirà di avere tutto sott'occhio e di facilitare la possibilità di intervento.

L'accesso d'amministratore è:
admin
admin

Per tutte le modifiche create un nuovo branch!

Buon lavoro!
